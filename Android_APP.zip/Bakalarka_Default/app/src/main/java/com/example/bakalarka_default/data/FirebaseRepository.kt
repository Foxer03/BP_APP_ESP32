package com.example.bakalarka_default.data

import androidx.compose.ui.graphics.Color
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.Query
import com.google.firebase.database.ValueEventListener

typealias RemoveListener = () -> Unit

private fun DataSnapshot.childFloat(key: String): Float {
    val v = child(key).value
    return when (v) {
        is Number -> v.toFloat()
        is String -> v.replace(",", ".").toFloatOrNull() ?: 0f
        else -> 0f
    }
}

fun aqiColor(aqi: Int): Color = when (aqi.coerceIn(1, 5)) {
    1 -> Color(0xFF2ECC71)
    2 -> Color(0xFFB7E51D)
    3 -> Color(0xFFFFC107)
    4 -> Color(0xFFFF8A00)
    else -> Color(0xFFE53935)
}

fun sensorRef(deviceId: String, sensorName: String): DatabaseReference {
    val db = FirebaseDatabase.getInstance()

    return when (deviceId) {
        "device_1" -> db.getReference("zariadenia/$deviceId/senzory/$sensorName")
        else -> db.getReference("zariadenia/$deviceId/${sensorName.lowercase()}")
    }
}

fun userRef(uid: String): DatabaseReference {
    return FirebaseDatabase.getInstance().getReference("users/$uid")
}

fun userPreferencesRef(uid: String): DatabaseReference = userRef(uid).child("preferences")
fun userDeviceNamesRef(uid: String): DatabaseReference = userRef(uid).child("deviceNames")

fun deviceDisplayName(deviceId: String, deviceNames: Map<String, String>): String {
    val custom = deviceNames[deviceId]?.trim().orEmpty()
    if (custom.isNotBlank()) return custom
    return availableDevices.firstOrNull { it.id == deviceId }?.defaultName ?: deviceId
}

fun ensureUserDefaults(uid: String) {
    val pref = userPreferencesRef(uid)
    pref.get().addOnSuccessListener { snapshot ->
        if (!snapshot.exists()) {
            pref.setValue(UserPreferences())
        }
    }

    val names = userDeviceNamesRef(uid)
    names.get().addOnSuccessListener { snapshot ->
        if (!snapshot.exists()) {
            val defaults = availableDevices.associate { it.id to it.defaultName }
            names.setValue(defaults)
        }
    }
}

fun Query.listen(onData: (DataSnapshot) -> Unit): RemoveListener {
    val listener = object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) = onData(snapshot)
        override fun onCancelled(error: DatabaseError) {}
    }
    addValueEventListener(listener)
    return { removeEventListener(listener) }
}

fun observeLatestBme680(deviceId: String, onData: (Bme680Env) -> Unit): RemoveListener {
    return sensorRef(deviceId, "BME680").limitToLast(1).listen { s ->
        val last = s.children.firstOrNull() ?: return@listen
        onData(Bme680Env(last.childFloat("teplota"), last.childFloat("vlhkost")))
    }
}

fun observeLatestEns160(deviceId: String, onData: (Ens160Data) -> Unit): RemoveListener {
    return sensorRef(deviceId, "ENS160").limitToLast(1).listen { s ->
        val last = s.children.firstOrNull() ?: return@listen
        onData(Ens160Data(last.childFloat("AQI"),
            last.childFloat("TVOC"), last.childFloat("eCO2")))
    }
}

fun observeLatestCcs811(deviceId: String, onData: (Ccs811Data) -> Unit): RemoveListener {
    return sensorRef(deviceId, "CCS811").limitToLast(1).listen { s ->
        val last = s.children.firstOrNull() ?: return@listen
        onData(Ccs811Data(last.childFloat("TVOC"), last.childFloat("eCO2")))
    }
}

fun observeLatestPm25(deviceId: String, onData: (Pm25Data) -> Unit): RemoveListener {
    return sensorRef(deviceId, "GP2Y1014AUOF").limitToLast(1).listen { s ->
        val last = s.children.firstOrNull() ?: return@listen
        val v = when {
            last.hasChild("PM2_5") -> last.childFloat("PM2_5")
            last.hasChild("pm25") -> last.childFloat("pm25")
            else -> 0f
        }
        onData(Pm25Data(v, last.key ?: ""))
    }
}

fun observeLatestKY037(deviceId: String, onData: (NoiseData) -> Unit): RemoveListener {
    return sensorRef(deviceId, "KY-037").limitToLast(1).listen { s ->
        val last = s.children.firstOrNull() ?: return@listen
        onData(NoiseData(
            dB = last.child("dB").getValue(Double::class.java)?.toFloat() ?: 0f,
            dateTimeLabel = last.key ?: ""
        ))
    }
}

fun observeLatestMax4466(deviceId: String, onData: (Max4466Data) -> Unit): RemoveListener {
    return sensorRef(deviceId, "MAX4466").limitToLast(1).listen { s ->
        val last = s.children.firstOrNull() ?: return@listen
        onData(Max4466Data(
            dB = last.child("dB").getValue(Double::class.java)?.toFloat() ?: 0f,
            dateTimeLabel = last.key ?: ""
        ))
    }
}

fun observeLatestSlm(deviceId: String, onData: (SlmData) -> Unit): RemoveListener {
    return sensorRef(deviceId, "SLM").limitToLast(1).listen { s ->
        val last = s.children.firstOrNull() ?: return@listen
        onData(SlmData(
            dBA = last.child("dBA").getValue(Double::class.java)?.toFloat() ?: 0f,
            dateTimeLabel = last.key ?: ""
        ))
    }
}

fun observeKy037History(deviceId: String, onData: (List<NoiseData>) -> Unit): RemoveListener {
    return sensorRef(deviceId, "KY-037").limitToLast(20).listen { s ->
        onData(
            s.children.mapNotNull { snap ->
                NoiseData(
                    dB = snap.child("dB").getValue(Double::class.java)?.toFloat() ?: 0f,
                    dateTimeLabel = snap.key ?: ""
                )
            }.sortedBy { it.dateTimeLabel }
        )
    }
}

fun observeMax4466History(deviceId: String, onData: (List<Max4466Data>) -> Unit): RemoveListener {
    return sensorRef(deviceId, "MAX4466").limitToLast(20).listen { s ->
        onData(
            s.children.mapNotNull { snap ->
                Max4466Data(
                    dB = snap.child("dB").getValue(Double::class.java)?.toFloat() ?: 0f,
                    dateTimeLabel = snap.key ?: ""
                )
            }.sortedBy { it.dateTimeLabel }
        )
    }
}

fun observeSlmHistory(deviceId: String, onData: (List<SlmData>) -> Unit): RemoveListener {
    return sensorRef(deviceId, "SLM").limitToLast(300).listen { s ->
        onData(
            s.children.mapNotNull { snap ->
                SlmData(
                    dBA = snap.child("dBA").getValue(Double::class.java)?.toFloat() ?: 0f,
                    dateTimeLabel = snap.key ?: ""
                )
            }.sortedBy { it.dateTimeLabel }
        )
    }
}
fun observeBmp280History(deviceId: String, onData: (List<Bmp280Data>) -> Unit): RemoveListener {
    return sensorRef(deviceId, "BMP280").limitToLast(100).listen { s ->
        onData(
            s.children.mapNotNull { snap ->
                Bmp280Data(
                    temp = snap.childFloat("temperature"),
                    pressure = snap.childFloat("pressure"),
                    dateTimeLabel = snap.key ?: ""
                )
            }.sortedBy { it.dateTimeLabel }
        )
    }
}
fun observeLatestBmp280(deviceId: String, onData: (Bmp280Data) -> Unit): RemoveListener {
    return sensorRef(deviceId, "bmp280").limitToLast(1).listen { s ->
        val last = s.children.firstOrNull() ?: return@listen
        onData(
            Bmp280Data(
                temp = last.childFloat("temperature"),
                pressure = last.childFloat("pressure"),
                dateTimeLabel = last.key ?: ""
            )
        )
    }
}
data class GpsData(
    val lat: Double = 0.0,
    val lon: Double = 0.0,
    val speed: Float = 0f
)

fun observeLatestGps(
    deviceId: String,
    onData: (GpsData) -> Unit
): RemoveListener {

    val ref = FirebaseDatabase.getInstance()
        .getReference("zariadenia/$deviceId/senzory/GPS")
        .limitToLast(1)

    return ref.listen { snapshot ->
        val last = snapshot.children.firstOrNull() ?: return@listen

        val lat = last.child("lat").getValue(Double::class.java) ?: 0.0
        val lon = last.child("lon").getValue(Double::class.java) ?: 0.0
        val speed = last.child("speed").getValue(Double::class.java)?.toFloat() ?: 0f

        onData(
            GpsData(
                lat = lat,
                lon = lon,
                speed = speed
            )
        )
    }
}