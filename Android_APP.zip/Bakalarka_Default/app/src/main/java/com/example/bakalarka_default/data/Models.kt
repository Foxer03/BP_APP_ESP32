package com.example.bakalarka_default.data

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

val NeonGreen = Color(0xFF3DFF8E)
val NeonBlue = Color(0xFF4CC9F0)
val NeonPurple = Color(0xFF9B5DE5)
val CardBackground = Color(0xFF161B22)
val DashboardBg = Color(0xFF0D1117)

interface ChartPoint {
    val value: Float
    val dateTimeLabel: String
}


data class NoiseData(val dB: Float = 0f, override val dateTimeLabel: String = "") : ChartPoint {
    override val value: Float get() = dB
}

data class Max4466Data(val dB: Float = 0f, override val dateTimeLabel: String = "") : ChartPoint {
    override val value: Float get() = dB
}

data class SlmData(val dBA: Float = 0f, override val dateTimeLabel: String = "") : ChartPoint {
    override val value: Float get() = dBA
}

// ===== ENV =====

data class Bme680Env(val teplota: Float = 0f, val vlhkost: Float = 0f)

data class Ens160Data(
    val aqi: Float = 0f,
    val tvoc: Float = 0f,
    val eco2: Float = 0f
)

data class Ccs811Data(
    val tvoc: Float = 0f,
    val eco2: Float = 0f
)

data class Pm25Data(val pm25: Float = 0f, override val dateTimeLabel: String = "") : ChartPoint {
    override val value: Float get() = pm25
}

// ===== NEW: BMP280 =====

data class Bmp280Data(
    val temp: Float = 0f,
    val pressure: Float = 0f,
    override val dateTimeLabel: String = ""
) : ChartPoint {
    override val value: Float get() = temp
}

// ===== UI =====

data class BottomNavItem(val label: String, val icon: ImageVector)

data class DeviceInfo(
    val id: String,
    val defaultName: String
)

data class UserPreferences(
    val selectedDeviceId: String = "device_1",
    val darkTheme: Boolean = true,
    val notificationsEnabled: Boolean = true
)

val availableDevices = listOf(
    DeviceInfo("device_1", "Zariadenie 1"),
    DeviceInfo("device_2", "Zariadenie 2"),
    DeviceInfo("device_3", "Zariadenie 3")
)