package com.example.bakalarka_default.notifications

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: "Alert"
        val body = message.notification?.body ?: ""

        showAlertNotification(
            applicationContext,
            title,
            body
        )
    }
}