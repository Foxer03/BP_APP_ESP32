package com.example.bakalarka_default.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.example.bakalarka_default.data.ensureUserDefaults
import com.example.bakalarka_default.data.listen
import com.example.bakalarka_default.data.userDeviceNamesRef
import com.example.bakalarka_default.data.userPreferencesRef
import com.example.bakalarka_default.ui.screens.DashboardScreen
import com.example.bakalarka_default.ui.screens.LoginScreen
import com.example.bakalarka_default.ui.theme.Bakalarka_DefaultTheme
import com.google.android.gms.auth.api.identity.BeginSignInRequest
import com.google.android.gms.auth.api.identity.SignInClient
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessaging

@Composable
fun RootApp(
    oneTapClient: SignInClient,
    signInRequest: BeginSignInRequest
) {
    val auth = FirebaseAuth.getInstance()
    var user by remember { mutableStateOf(auth.currentUser) }

    var selectedDevice by rememberSaveable { mutableStateOf("device_1") }
    var darkTheme by rememberSaveable { mutableStateOf(true) }
    var notificationsEnabled by rememberSaveable { mutableStateOf(true) }
    var deviceNames by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { user = it.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    DisposableEffect(user?.uid) {
        val uid = user?.uid
        if (uid == null) {
            deviceNames = emptyMap()
            onDispose { }
        } else {
            ensureUserDefaults(uid)

            val prefRemove = userPreferencesRef(uid).listen { snapshot ->
                selectedDevice = snapshot.child("selectedDeviceId").getValue(String::class.java) ?: "device_1"
                darkTheme = snapshot.child("darkTheme").getValue(Boolean::class.java) ?: true
                notificationsEnabled = snapshot.child("notificationsEnabled").getValue(Boolean::class.java) ?: true
            }

            val namesRemove = userDeviceNamesRef(uid).listen { snapshot ->
                deviceNames = snapshot.children.associate { it.key.orEmpty() to (it.getValue(String::class.java) ?: "") }
            }

            onDispose {
                prefRemove()
                namesRemove()
            }
        }
    }

    LaunchedEffect(notificationsEnabled, user?.uid) {
        if (user != null) {
            if (notificationsEnabled) {
                FirebaseMessaging.getInstance().subscribeToTopic("alerts")
            } else {
                FirebaseMessaging.getInstance().unsubscribeFromTopic("alerts")
            }
        }
    }

    Bakalarka_DefaultTheme(darkTheme = darkTheme) {
        if (user == null) {
            LoginScreen(oneTapClient, signInRequest)
        } else {
            DashboardScreen(
                user = user!!,
                selectedDevice = selectedDevice,
                onDeviceChange = {
                    selectedDevice = it
                    userPreferencesRef(user!!.uid).child("selectedDeviceId").setValue(it)
                },
                darkTheme = darkTheme,
                onDarkThemeChange = {
                    darkTheme = it
                    userPreferencesRef(user!!.uid).child("darkTheme").setValue(it)
                },
                notificationsEnabled = notificationsEnabled,
                onNotificationsChange = {
                    notificationsEnabled = it
                    userPreferencesRef(user!!.uid).child("notificationsEnabled").setValue(it)
                },
                deviceNames = deviceNames,
                onRenameDevice = { deviceId, newName ->
                    userDeviceNamesRef(user!!.uid).child(deviceId).setValue(newName)
                },
                onLogout = { auth.signOut() }
            )
        }
    }
}
