package com.example.bakalarka_default.ui.screens

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bakalarka_default.data.DashboardBg
import com.google.android.gms.auth.api.identity.BeginSignInRequest
import com.google.android.gms.auth.api.identity.SignInClient
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

@Composable
fun LoginScreen(oneTapClient: SignInClient, signInRequest: BeginSignInRequest) {
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val cred = oneTapClient.getSignInCredentialFromIntent(res.data)
            cred.googleIdToken?.let {
                FirebaseAuth.getInstance().signInWithCredential(
                    GoogleAuthProvider.getCredential(it, null)
                )
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize().background(DashboardBg),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("IoT Noise Monitor", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(40.dp))
            Button(
                onClick = {
                    oneTapClient.beginSignIn(signInRequest).addOnSuccessListener {
                        launcher.launch(IntentSenderRequest.Builder(it.pendingIntent.intentSender).build())
                    }
                }
            ) {
                Text("Prihlásiť sa cez Google")
            }
        }
    }
}
