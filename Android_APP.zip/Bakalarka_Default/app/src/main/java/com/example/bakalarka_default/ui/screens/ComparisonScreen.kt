package com.example.bakalarka_default.ui.screens

import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bakalarka_default.data.*
import com.example.bakalarka_default.ui.components.*
import java.time.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComparisonScreen(selectedDevice: String) {

    val config = getDeviceConfig(selectedDevice)

    val options = buildList {
        add("Nič")

        config.sensors.forEach {
            when (it) {
                SensorType.KY037 -> add("KY-037")
                SensorType.MAX4466 -> add("MAX4466")
                SensorType.SLM -> add("SLM")
                SensorType.BMP280 -> {
                    add("BMP280 Teplota")
                    add("BMP280 Tlak")
                }
                else -> {}
            }
        }
    }

    var sel1 by remember { mutableStateOf(options.getOrElse(1) { "Nič" }) }
    var sel2 by remember { mutableStateOf("Nič") }
    var sel3 by remember { mutableStateOf("Nič") }

    var exp1 by remember { mutableStateOf(false) }
    var exp2 by remember { mutableStateOf(false) }
    var exp3 by remember { mutableStateOf(false) }

    // ===== DATA =====
    var kyHis by remember { mutableStateOf<List<NoiseData>>(emptyList()) }
    var maxHis by remember { mutableStateOf<List<Max4466Data>>(emptyList()) }
    var slmHis by remember { mutableStateOf<List<SlmData>>(emptyList()) }
    var bmpHis by remember { mutableStateOf<List<Bmp280Data>>(emptyList()) }

    DisposableEffect(selectedDevice) {
        val removers = mutableListOf<() -> Unit>()

        if (config.sensors.contains(SensorType.KY037)) {
            removers += observeKy037History(selectedDevice) { kyHis = it }
        }

        if (config.sensors.contains(SensorType.MAX4466)) {
            removers += observeMax4466History(selectedDevice) { maxHis = it }
        }

        if (config.sensors.contains(SensorType.SLM)) {
            removers += observeSlmHistory(selectedDevice) { slmHis = it }
        }

        if (config.sensors.contains(SensorType.BMP280)) {
            removers += observeBmp280History(selectedDevice) { bmpHis = it }
        }

        onDispose { removers.forEach { it.invoke() } }
    }

    fun getData(name: String): List<ChartPoint> = when (name) {
        "KY-037" -> kyHis
        "MAX4466" -> maxHis
        "SLM" -> slmHis
        "BMP280 Teplota" -> bmpHis.map {
            NoiseData(it.temp, it.dateTimeLabel)
        }
        "BMP280 Tlak" -> bmpHis.map {
            NoiseData(it.pressure, it.dateTimeLabel)
        }
        else -> emptyList()
    }

    fun unitFor(name: String): String = when (name) {
        "SLM" -> "dBA"
        "BMP280 Teplota" -> "°C"
        "BMP280 Tlak" -> "hPa"
        else -> "dB"
    }

    fun isTaken(name: String, except: Int): Boolean {
        if (name == "Nič") return false
        val list = listOf(sel1, sel2, sel3)
        return list.withIndex().any { (i, v) -> i != except && v == name }
    }

    fun autoFix(slot: Int) {
        val list = mutableListOf(sel1, sel2, sel3)
        val current = list[slot]

        list.withIndex()
            .filter { (i, v) -> i != slot && v == current }
            .forEach { (i, _) -> list[i] = "Nič" }

        sel1 = list[0]
        sel2 = list[1]
        sel3 = list[2]
    }

    val context = androidx.compose.ui.platform.LocalContext.current
    val zone = remember { ZoneId.systemDefault() }

    var showRangePicker by remember { mutableStateOf(false) }
    val pickerState = rememberDateRangePickerState()

    var startDay by remember { mutableStateOf<LocalDate?>(null) }
    var endDay by remember { mutableStateOf<LocalDate?>(null) }

    var startTime by remember { mutableStateOf(LocalTime.of(0, 0)) }
    var endTime by remember { mutableStateOf(LocalTime.of(23, 59)) }

    fun startDT() = startDay?.atTime(startTime)
    fun endDT() = endDay?.atTime(endTime)

    fun fmt(t: LocalTime) = "%02d:%02d".format(t.hour, t.minute)

    if (showRangePicker) {
        DatePickerDialog(
            onDismissRequest = { showRangePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedStartDateMillis?.let {
                        startDay = Instant.ofEpochMilli(it).atZone(zone).toLocalDate()
                    }
                    pickerState.selectedEndDateMillis?.let {
                        endDay = Instant.ofEpochMilli(it).atZone(zone).toLocalDate()
                    }
                    showRangePicker = false
                }) { Text("Použiť") }
            },
            dismissButton = {
                TextButton(onClick = { showRangePicker = false }) { Text("Zrušiť") }
            }
        ) {
            DateRangePicker(state = pickerState)
        }
    }

    fun openTime(initial: LocalTime, onPicked: (LocalTime) -> Unit) {
        TimePickerDialog(
            context,
            { _, h, m -> onPicked(LocalTime.of(h, m)) },
            initial.hour,
            initial.minute,
            true
        ).show()
    }

    fun keyToDT(label: String): LocalDateTime? {
        if (label.length < 10) return null
        val date = LocalDate.parse(label.substring(0, 10))
        val time = label.substringAfter("_", "00:00").replace("-", ":")
        val parts = time.split(":")
        return date.atTime(
            parts.getOrNull(0)?.toIntOrNull() ?: 0,
            parts.getOrNull(1)?.toIntOrNull() ?: 0
        )
    }

    fun filter(data: List<ChartPoint>): List<ChartPoint> {
        val s = startDT()
        val e = endDT()
        if (s == null || e == null) return data

        return data.filter {
            val dt = keyToDT(it.dateTimeLabel) ?: return@filter false
            !dt.isBefore(s) && !dt.isAfter(e)
        }
    }

    fun buildDatasets(): Triple<List<Pair<List<ChartPoint>, Color>>, List<String>, String> {
        val ds = mutableListOf<Pair<List<ChartPoint>, Color>>()
        val names = mutableListOf<String>()
        val units = mutableSetOf<String>()

        fun add(name: String, color: Color) {
            if (name == "Nič") return
            val data = filter(getData(name))
            if (data.isNotEmpty()) {
                ds += data to color
                names += name
                units += unitFor(name)
            }
        }

        add(sel1, NeonGreen)
        add(sel2, NeonPurple)
        add(sel3, NeonBlue)

        return Triple(ds, names, units.firstOrNull() ?: "")
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
    ) {

        Text("Porovnanie senzorov", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(6.dp))
        Text("Dynamické podľa zariadenia", color = Color(0xFF8B949E), fontSize = 12.sp)

        Spacer(Modifier.height(14.dp))

        CompDropdownNoDuplicates("Senzor 1", sel1, exp1, { sel1 = it; autoFix(0) }, { exp1 = it }, options, { isTaken(it, 0) })
        Spacer(Modifier.height(8.dp))
        CompDropdownNoDuplicates("Senzor 2", sel2, exp2, { sel2 = it; autoFix(1) }, { exp2 = it }, options, { isTaken(it, 1) })
        Spacer(Modifier.height(8.dp))
        CompDropdownNoDuplicates("Senzor 3", sel3, exp3, { sel3 = it; autoFix(2) }, { exp3 = it }, options, { isTaken(it, 2) })

        Spacer(Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { showRangePicker = true }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.DateRange, null)
                Spacer(Modifier.width(8.dp))
                Text("Dni")
            }

            OutlinedButton(onClick = {
                startDay = null
                endDay = null
            }) { Text("Reset") }
        }

        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { openTime(startTime) { startTime = it } }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Schedule, null)
                Spacer(Modifier.width(8.dp))
                Text("Od ${fmt(startTime)}")
            }

            Button(onClick = { openTime(endTime) { endTime = it } }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Schedule, null)
                Spacer(Modifier.width(8.dp))
                Text("Do ${fmt(endTime)}")
            }
        }

        Spacer(Modifier.height(14.dp))

        Column(
            modifier = Modifier.fillMaxWidth().background(CardBackground).padding(16.dp)
        ) {

            val (datasets, names, unit) = buildDatasets()

            Box(modifier = Modifier.fillMaxWidth().height(340.dp)) {
                if (datasets.isEmpty()) {
                    Text("Žiadne dáta", color = Color.Gray)
                } else {
                    CoreGraphEngine(datasets, unit)
                }
            }

            Spacer(Modifier.height(12.dp))

            ExportSvgButton(
                svgFileName = "porovnanie.svg",
                svgProvider = { buildLineGraphSvg(datasets, names, unit) }
            )
        }

        Spacer(Modifier.height(40.dp))
    }
}