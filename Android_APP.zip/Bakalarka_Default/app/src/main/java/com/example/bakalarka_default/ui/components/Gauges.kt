package com.example.bakalarka_default.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.bakalarka_default.data.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.maps.android.compose.CameraPositionState

@Composable
fun MainGridDynamic(
    config: DeviceConfig,
    ky: Float,
    max: Float,
    slm: Float,
    ensAqi: Float,
    ensTvoc: Float,
    ensEco2: Float,
    ccsEco2: Float,
    ccsTvoc: Float,
    pm25: Float,
    bmpTemp: Float,
    showMap: Boolean = false,
    gpsLat: Double = 0.0,
    gpsLon: Double = 0.0,
    gpsSpeed: Float = 0f,
    cameraPositionState: CameraPositionState? = null
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        if (showMap) {
            item(span = { GridItemSpan(2) }) {

                val markerPosition =
                    if (gpsLat != 0.0 && gpsLon != 0.0) {
                        LatLng(gpsLat, gpsLon)
                    } else {
                        LatLng(49.223, 18.739)
                    }

                Column {
                    Text(
                        text = "Poloha zariadenia",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = if (gpsLat != 0.0 && gpsLon != 0.0) {
                            "Lat: %.6f   Lon: %.6f".format(gpsLat, gpsLon)
                        } else {
                            "Čakám na GPS dáta..."
                        },
                        color = Color(0xFF8B949E),
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    AndroidView(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(24.dp)),
                        factory = { context ->
                            MapView(context).apply {
                                onCreate(null)
                                onResume()

                                getMapAsync { googleMap ->
                                    googleMap.uiSettings.apply {
                                        isZoomControlsEnabled = true
                                        isZoomGesturesEnabled = true
                                        isScrollGesturesEnabled = true
                                        isRotateGesturesEnabled = true
                                        isTiltGesturesEnabled = true
                                    }

                                    googleMap.moveCamera(
                                        CameraUpdateFactory.newLatLngZoom(
                                            markerPosition,
                                            16f
                                        )
                                    )

                                    googleMap.clear()
                                    googleMap.addMarker(
                                        MarkerOptions()
                                            .position(markerPosition)
                                            .title("Vonku")
                                            .snippet(
                                                if (gpsLat != 0.0 && gpsLon != 0.0) {
                                                    "Rýchlosť: $gpsSpeed km/h"
                                                } else {
                                                    "Čakám na GPS dáta..."
                                                }
                                            )
                                    )
                                }
                            }
                        },
                        update = { mapView ->
                            mapView.getMapAsync { googleMap ->
                                googleMap.clear()

                                googleMap.addMarker(
                                    MarkerOptions()
                                        .position(markerPosition)
                                        .title("Vonku")
                                        .snippet(
                                            if (gpsLat != 0.0 && gpsLon != 0.0) {
                                                "Rýchlosť: $gpsSpeed km/h"
                                            } else {
                                                "Čakám na GPS dáta..."
                                            }
                                        )
                                )

                                googleMap.animateCamera(
                                    CameraUpdateFactory.newLatLngZoom(
                                        markerPosition,
                                        16f
                                    )
                                )
                            }
                        }
                    )
                }
            }
        }

        config.sensors.forEach { sensor ->
            item {
                when (sensor) {
                    SensorType.KY037 ->
                        GaugeMetricCard("KY-037", ky, "dB", NeonGreen, 30f, 110f)

                    SensorType.MAX4466 ->
                        GaugeMetricCard("MAX4466", max, "dB", NeonPurple, 30f, 110f)

                    SensorType.SLM ->
                        GaugeMetricCard("SLM", slm, "dBA", NeonBlue, 30f, 110f)

                    SensorType.ENS160 ->
                        EnsGaugeCard(ensAqi, ensTvoc, ensEco2)

                    SensorType.CCS811 ->
                        CcsGaugeCard(ccsEco2, ccsTvoc)

                    SensorType.PM25 ->
                        Pm25GaugeCard(pm25)

                    SensorType.BMP280 ->
                        GaugeMetricCard("BMP280", bmpTemp, "°C", NeonBlue, 0f, 40f)
                }
            }
        }
    }
}

@Composable
fun GaugeMetricCard(
    title: String,
    value: Float,
    unit: String,
    color: Color,
    min: Float,
    max: Float
) {
    val progress = ((value - min) / (max - min)).coerceIn(0f, 1f)

    Column(
        modifier = Modifier
            .height(170.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(CardBackground)
            .padding(16.dp)
    ) {
        Text(title, color = Color.Gray, fontSize = 12.sp)

        Spacer(Modifier.height(12.dp))

        RingGauge(progress, color, Modifier.size(104.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    value.toInt().toString(),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp
                )
                Text(unit, color = Color(0xFFC9D1D9), fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun EnsGaugeCard(aqi: Float, tvoc: Float, eco2: Float) {
    val aqiInt = aqi.toInt().coerceIn(1, 5)

    Column(
        modifier = Modifier
            .height(170.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(CardBackground)
            .padding(16.dp)
    ) {
        Text("ENS160", color = Color.Gray)

        Spacer(Modifier.height(12.dp))

        RingGauge(aqiInt / 5f, aqiColor(aqiInt), Modifier.size(104.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(aqiInt.toString(), color = Color.White, fontWeight = FontWeight.Bold)
                Text("AQI", color = Color.LightGray)
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("TVOC ${tvoc.toInt()} ppb", color = Color.Gray, fontSize = 11.sp)
        Text("eCO2 ${eco2.toInt()} ppm", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun CcsGaugeCard(eco2: Float, tvoc: Float) {
    val progress = ((eco2 - 400f) / 1600f).coerceIn(0f, 1f)

    Column(
        modifier = Modifier
            .height(170.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(CardBackground)
            .padding(16.dp)
    ) {
        Text("CCS811", color = Color.Gray)

        Spacer(Modifier.height(12.dp))

        RingGauge(progress, NeonBlue, Modifier.size(104.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(eco2.toInt().toString(), color = Color.White, fontWeight = FontWeight.Bold)
                Text("ppm", color = Color.LightGray)
            }
        }

        Spacer(Modifier.height(8.dp))
        Text("TVOC ${tvoc.toInt()} ppb", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun Pm25GaugeCard(pm25: Float) {
    val progress = (pm25 / 150f).coerceIn(0f, 1f)

    Column(
        modifier = Modifier
            .height(170.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(CardBackground)
            .padding(16.dp)
    ) {
        Text("PM2.5", color = Color.Gray)

        Spacer(Modifier.height(12.dp))

        RingGauge(progress, NeonPurple, Modifier.size(104.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(pm25.toInt().toString(), color = Color.White, fontWeight = FontWeight.Bold)
                Text("µg/m³", color = Color.LightGray)
            }
        }
    }
}

@Composable
fun RingGauge(
    progress: Float,
    color: Color,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val stroke = 10f
            val d = size.minDimension - stroke
            val topLeft = Offset((size.width - d) / 2, (size.height - d) / 2)

            drawArc(
                color = Color.White.copy(alpha = 0.1f),
                startAngle = 140f,
                sweepAngle = 260f,
                useCenter = false,
                topLeft = topLeft,
                size = Size(d, d),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )

            drawArc(
                color = color,
                startAngle = 140f,
                sweepAngle = 260f * progress,
                useCenter = false,
                topLeft = topLeft,
                size = Size(d, d),
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }

        content()
    }
}

@Composable
fun BmeEnvBanner(
    tempC: Float,
    humidity: Float,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(Color.Black.copy(alpha = 0.55f))
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(10.dp)
                .clip(androidx.compose.foundation.shape.CircleShape)
                .background(Color(0xFF58A6FF))
        )

        Spacer(Modifier.width(12.dp))

        Text(
            text = "🌡 ${tempC.toInt()}°C",
            color = Color.White,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(Modifier.width(16.dp))

        Text(
            text = "💧 ${humidity.toInt()}%",
            color = Color.White,
            fontWeight = FontWeight.SemiBold
        )
    }
}