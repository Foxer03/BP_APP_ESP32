package com.example.bakalarka_default.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.bakalarka_default.data.*
import com.example.bakalarka_default.ui.components.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.auth.FirebaseUser
import com.google.maps.android.compose.rememberCameraPositionState

@Composable
fun DashboardScreen(
    user: FirebaseUser,
    selectedDevice: String,
    onDeviceChange: (String) -> Unit,
    darkTheme: Boolean,
    onDarkThemeChange: (Boolean) -> Unit,
    notificationsEnabled: Boolean,
    onNotificationsChange: (Boolean) -> Unit,
    deviceNames: Map<String, String>,
    onRenameDevice: (String, String) -> Unit,
    onLogout: () -> Unit
) {
    val config = getDeviceConfig(selectedDevice)

    var bmeTemp by remember { mutableStateOf(0f) }
    var bmeHum by remember { mutableStateOf(0f) }
    var bmpTemp by remember { mutableStateOf(0f) }

    var kyDb by remember { mutableStateOf(0f) }
    var maxDb by remember { mutableStateOf(0f) }
    var slmDb by remember { mutableStateOf(0f) }
    var ensAqi by remember { mutableStateOf(0f) }
    var ensTvoc by remember { mutableStateOf(0f) }
    var ensEco2 by remember { mutableStateOf(0f) }
    var ccsTvoc by remember { mutableStateOf(0f) }
    var ccsEco2 by remember { mutableStateOf(0f) }
    var pm25 by remember { mutableStateOf(0f) }

    var gpsLat by remember { mutableStateOf(0.0) }
    var gpsLon by remember { mutableStateOf(0.0) }
    var gpsSpeed by remember { mutableStateOf(0f) }

    var selectedTab by remember { mutableStateOf(0) }
    var showAccount by remember { mutableStateOf(false) }

    DisposableEffect(selectedDevice) {
        val removers = mutableListOf<() -> Unit>()

        if (config.sensors.contains(SensorType.KY037))
            removers += observeLatestKY037(selectedDevice) { kyDb = it.dB }

        if (config.sensors.contains(SensorType.MAX4466))
            removers += observeLatestMax4466(selectedDevice) { maxDb = it.dB }

        if (config.sensors.contains(SensorType.SLM))
            removers += observeLatestSlm(selectedDevice) { slmDb = it.dBA }

        if (config.sensors.contains(SensorType.ENS160))
            removers += observeLatestEns160(selectedDevice) {
                ensAqi = it.aqi
                ensTvoc = it.tvoc
                ensEco2 = it.eco2
            }

        if (config.sensors.contains(SensorType.CCS811))
            removers += observeLatestCcs811(selectedDevice) {
                ccsTvoc = it.tvoc
                ccsEco2 = it.eco2
            }

        if (config.sensors.contains(SensorType.PM25))
            removers += observeLatestPm25(selectedDevice) { pm25 = it.pm25 }

        if (config.sensors.contains(SensorType.BMP280)) {
            removers += observeLatestBmp280(selectedDevice) {
                bmpTemp = it.temp
            }
        }

        if (selectedDevice == "device_1") {
            removers += observeLatestGps(selectedDevice) {
                gpsLat = it.lat
                gpsLon = it.lon
                gpsSpeed = it.speed
            }

            removers += observeLatestBme680(selectedDevice) {
                bmeTemp = it.teplota
                bmeHum = it.vlhkost
            }
        }

        onDispose { removers.forEach { it.invoke() } }
    }

    val tabs = listOf(
        BottomNavItem("Domov", Icons.Default.Home),
        BottomNavItem("Grafy", Icons.Default.ShowChart),
        BottomNavItem("Porovnať", Icons.Default.Compare),
        BottomNavItem("Viac", Icons.Default.MoreHoriz)
    )

    val defaultPosition = LatLng(49.223, 18.739)

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(defaultPosition, 12f)
    }

    LaunchedEffect(gpsLat, gpsLon) {
        if (gpsLat != 0.0 && gpsLon != 0.0) {
            cameraPositionState.animate(
                CameraUpdateFactory.newLatLngZoom(
                    LatLng(gpsLat, gpsLon),
                    16f
                )
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DashboardBg)
    ) {

        // ===== TOP BAR =====
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .padding(horizontal = 16.dp)
                .align(Alignment.TopStart),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF30363D))
                    .clickable { showAccount = true }
            ) {
                if (user.photoUrl != null) {
                    AsyncImage(
                        model = user.photoUrl,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        Icons.Default.Person,
                        null,
                        tint = Color.White,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }

            Spacer(Modifier.width(16.dp))

            Column {
                Text(
                    tabs[selectedTab].label,
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    deviceDisplayName(selectedDevice, deviceNames),
                    color = Color(0xFF8B949E),
                    fontSize = 12.sp
                )
            }
        }

        // ===== CONTENT =====
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 80.dp, bottom = 100.dp)
        ) {
            when (selectedTab) {

                0 -> {
                    Column(
                        modifier = Modifier.fillMaxSize()
                    ) {

                        if (selectedDevice == "device_1") {
                            BmeEnvBanner(
                                tempC = bmeTemp,
                                humidity = bmeHum,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                            )
                        }

                        MainGridDynamic(
                            config = config,
                            ky = kyDb,
                            max = maxDb,
                            slm = slmDb,
                            ensAqi = ensAqi,
                            ensTvoc = ensTvoc,
                            ensEco2 = ensEco2,
                            ccsEco2 = ccsEco2,
                            ccsTvoc = ccsTvoc,
                            pm25 = pm25,
                            bmpTemp = bmpTemp,

                            showMap = selectedDevice == "device_1",
                            gpsLat = gpsLat,
                            gpsLon = gpsLon,
                            gpsSpeed = gpsSpeed,
                            cameraPositionState = cameraPositionState
                        )
                    }
                }

                1 -> GraphScreen(selectedDevice)

                2 -> ComparisonScreen(selectedDevice)

                else -> MoreScreen(
                    selectedDevice = selectedDevice,
                    onDeviceChange = onDeviceChange,
                    darkTheme = darkTheme,
                    onDarkThemeChange = onDarkThemeChange,
                    notificationsEnabled = notificationsEnabled,
                    onNotificationsChange = onNotificationsChange,
                    deviceNames = deviceNames,
                    onRenameDevice = onRenameDevice
                )
            }
        }

        // ===== BOTTOM BAR =====
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 20.dp)
        ) {
            PillBottomBar(tabs, selectedTab) {
                selectedTab = it
            }
        }
    }

    if (showAccount) {
        AccountBottomSheet(user, onLogout) {
            showAccount = false
        }
    }
}