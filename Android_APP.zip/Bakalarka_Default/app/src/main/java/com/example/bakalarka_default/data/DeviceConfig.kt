package com.example.bakalarka_default.data

enum class SensorType {
    KY037,
    MAX4466,
    SLM,
    BMP280,
    ENS160,
    CCS811,
    PM25
}

data class DeviceConfig(
    val sensors: List<SensorType>
)

fun getDeviceConfig(deviceId: String): DeviceConfig {
    return when (deviceId) {

        "device_1" -> DeviceConfig(
            sensors = listOf(
                SensorType.KY037,
                SensorType.MAX4466,
                SensorType.SLM,
                SensorType.ENS160,
                SensorType.CCS811,
                SensorType.PM25
            )
        )

        "device_2", "device_3" -> DeviceConfig(
            sensors = listOf(
                SensorType.BMP280,
                SensorType.MAX4466
            )
        )

        else -> DeviceConfig(emptyList())
    }
}