package com.example.bakalarka_default.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Dashboard (dark) paleta – inšpirovaná „monitoring“ UI.
 * Fotka je iba moodboard: farby sú upravené tak, aby boli čitateľné a konzistentné.
 */

// Neutrals
val Ink = Color(0xFF0B0F14)        // app background
val Ink2 = Color(0xFF0F1620)       // elevated background
val Surface0 = Color(0xFF101826)   // card surface
val Surface1 = Color(0xFF141F2F)   // card surface (slightly brighter)
val Border = Color(0xFF213149)

// Text
val TextPrimary = Color(0xFFEAF0FF)
val TextSecondary = Color(0xFFA9B6CF)

// Accents
val NeonGreen = Color(0xFF39FF88)
val NeonCyan = Color(0xFF35D6FF)
val NeonAmber = Color(0xFFFFC857)
val NeonRed = Color(0xFFFF5C7A)
