package com.example.bakalarka_default.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DashboardDarkScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = Ink,
    secondary = NeonCyan,
    onSecondary = Ink,
    tertiary = NeonAmber,
    onTertiary = Ink,
    background = Ink,
    onBackground = TextPrimary,
    surface = Surface0,
    onSurface = TextPrimary,
    surfaceVariant = Surface1,
    onSurfaceVariant = TextSecondary,
    outline = Border,
    error = NeonRed,
    onError = Ink
)

private val DashboardLightScheme = lightColorScheme(
    primary = NeonGreen,
    onPrimary = Ink,
    secondary = NeonCyan,
    onSecondary = Ink,
    tertiary = NeonAmber,
    onTertiary = Ink,
    background = Color(0xFFF6F8FC),
    onBackground = Color(0xFF0B0F14),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0B0F14),
    surfaceVariant = Color(0xFFF0F3FA),
    onSurfaceVariant = Color(0xFF334155),
    outline = Color(0xFFCBD5E1),
    error = NeonRed,
    onError = Ink
)

@Composable
fun Bakalarka_DefaultTheme(
    /**
     * Dizajn tohto projektu je cielene „dark dashboard“. Preto je default = true.
     */
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val scheme = if (darkTheme) DashboardDarkScheme else DashboardLightScheme

    MaterialTheme(
        colorScheme = scheme,
        typography = Typography,
        content = content
    )
}
