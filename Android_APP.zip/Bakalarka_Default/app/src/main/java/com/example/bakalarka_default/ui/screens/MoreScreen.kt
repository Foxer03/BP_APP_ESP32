package com.example.bakalarka_default.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.bakalarka_default.data.DeviceInfo
import com.example.bakalarka_default.data.availableDevices
import com.example.bakalarka_default.data.deviceDisplayName
import com.example.bakalarka_default.ui.components.SettingsMenuCard
import com.example.bakalarka_default.ui.components.SettingsSectionTitle
import com.example.bakalarka_default.ui.components.SettingsSwitchCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(
    selectedDevice: String,
    onDeviceChange: (String) -> Unit,
    darkTheme: Boolean,
    onDarkThemeChange: (Boolean) -> Unit,
    notificationsEnabled: Boolean,
    onNotificationsChange: (Boolean) -> Unit,
    deviceNames: Map<String, String>,
    onRenameDevice: (String, String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var renameDialogDevice by remember { mutableStateOf<DeviceInfo?>(null) }
    var renameText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SettingsSectionTitle("Zariadenie")

        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(
                value = deviceDisplayName(selectedDevice, deviceNames),
                onValueChange = {},
                readOnly = true,
                label = { Text("Vybrané zariadenie") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )

            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                availableDevices.forEach { device ->
                    DropdownMenuItem(
                        text = { Text(deviceDisplayName(device.id, deviceNames)) },
                        onClick = {
                            onDeviceChange(device.id)
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        SettingsSectionTitle("Premenovanie zariadení")

        availableDevices.forEach { device ->
            SettingsMenuCard(
                icon = Icons.Default.Edit,
                title = deviceDisplayName(device.id, deviceNames),
                subtitle = "ID: ${device.id}",
                onClick = {
                    renameDialogDevice = device
                    renameText = deviceDisplayName(device.id, deviceNames)
                }
            )
        }

        Spacer(Modifier.height(6.dp))
        SettingsSectionTitle("Preferencie")

        SettingsSwitchCard(
            icon = Icons.Default.DarkMode,
            title = "Tmavá téma",
            subtitle = if (darkTheme) "Zapnutá" else "Vypnutá",
            checked = darkTheme,
            onCheckedChange = onDarkThemeChange
        )

        SettingsSwitchCard(
            icon = Icons.Default.Notifications,
            title = "Notifikácie",
            subtitle = if (notificationsEnabled) "Povolené" else "Zakázané",
            checked = notificationsEnabled,
            onCheckedChange = onNotificationsChange
        )

        SettingsMenuCard(
            icon = Icons.Default.Info,
            title = "Informácie o aplikácii",
            subtitle = "Verzia, autor, detail projektu"
        )
    }

    renameDialogDevice?.let { device ->
        AlertDialog(
            onDismissRequest = { renameDialogDevice = null },
            title = { Text("Premenovať zariadenie") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    label = { Text("Názov zariadenia") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val finalName = renameText.trim()
                    if (finalName.isNotEmpty()) onRenameDevice(device.id, finalName)
                    renameDialogDevice = null
                }) {
                    Text("Uložiť")
                }
            },
            dismissButton = {
                TextButton(onClick = { renameDialogDevice = null }) {
                    Text("Zrušiť")
                }
            }
        )
    }
}
