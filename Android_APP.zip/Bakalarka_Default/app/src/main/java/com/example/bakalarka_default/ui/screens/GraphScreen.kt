package com.example.bakalarka_default.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bakalarka_default.data.*
import com.example.bakalarka_default.ui.components.ChartCard
import com.example.bakalarka_default.ui.components.TimeRangePicker

@Composable
fun GraphScreen(selectedDevice: String) {

    val config = getDeviceConfig(selectedDevice)

    var kyHis by remember { mutableStateOf<List<NoiseData>>(emptyList()) }
    var maxHis by remember { mutableStateOf<List<Max4466Data>>(emptyList()) }
    var slmHis by remember { mutableStateOf<List<SlmData>>(emptyList()) }
    var bmpHis by remember { mutableStateOf<List<Bmp280Data>>(emptyList()) }

    DisposableEffect(selectedDevice) {
        val removers = mutableListOf<() -> Unit>()

        if (config.sensors.contains(SensorType.KY037))
            removers += observeKy037History(selectedDevice) { kyHis = it }

        if (config.sensors.contains(SensorType.MAX4466))
            removers += observeMax4466History(selectedDevice) { maxHis = it }

        if (config.sensors.contains(SensorType.SLM))
            removers += observeSlmHistory(selectedDevice) { slmHis = it }

        if (config.sensors.contains(SensorType.BMP280))
            removers += observeBmp280History(selectedDevice) { bmpHis = it }

        onDispose { removers.forEach { it.invoke() } }
    }

    val base = kyHis.ifEmpty { maxHis.ifEmpty { slmHis.ifEmpty { bmpHis } } }

    var range by remember(base.size) {
        val last = (base.size - 1).coerceAtLeast(1)
        mutableStateOf(0f..last.toFloat())
    }

    val s = range.start.toInt()
    val e = range.endInclusive.toInt()

    fun <T> slice(list: List<T>) =
        if (list.isEmpty()) emptyList()
        else list.subList(s.coerceIn(0, list.lastIndex), e.coerceIn(0, list.lastIndex) + 1)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        item {
            Text("Grafy podľa zariadenia", color = Color.Gray, fontSize = 12.sp)
        }

        item {
            TimeRangePicker(base, range) { range = it }
        }

        // BMP280
        if (config.sensors.contains(SensorType.BMP280)) {

            item {
                ChartCard(
                    "Teplota (BMP280)",
                    slice(bmpHis.map { it.copy() }),
                    NeonGreen,
                    "°C"
                )
            }

            item {
                ChartCard(
                    "Tlak (BMP280)",
                    slice(bmpHis.map {
                        object : ChartPoint {
                            override val value = it.pressure
                            override val dateTimeLabel = it.dateTimeLabel
                        }
                    }),
                    NeonBlue,
                    "hPa"
                )
            }
        }

        if (config.sensors.contains(SensorType.MAX4466))
            item { ChartCard("MAX4466", slice(maxHis), NeonPurple, "dB") }

        if (config.sensors.contains(SensorType.KY037))
            item { ChartCard("KY-037", slice(kyHis), NeonGreen, "dB") }

        if (config.sensors.contains(SensorType.SLM))
            item { ChartCard("SLM", slice(slmHis), NeonBlue, "dBA") }
    }
}