package com.example.bakalarka_default.notifications

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCM", "🔥 NEW TOKEN: $token")
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)

        Log.d("FCM", "🔥 MESSAGE RECEIVED: ${message.notification?.title}")

        message.notification?.let {
            showAlertNotification(
                applicationContext,
                it.title ?: "Alert",
                it.body ?: ""
            )
        }
    }
}