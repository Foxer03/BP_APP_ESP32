package com.example.bakalarka_default.notifications

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.bakalarka_default.ALERTS_CHANNEL_ID
import com.example.bakalarka_default.R
import com.example.bakalarka_default.ensureAlertsChannel
import kotlin.random.Random

fun showAlertNotification(
    context: Context,
    title: String,
    message: String
) {
    ensureAlertsChannel(context)

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED

        if (!granted) return
    }

    val notification = NotificationCompat.Builder(context, ALERTS_CHANNEL_ID)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle(title)
        .setContentText(message)
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setAutoCancel(true)
        .build()

    try {
        NotificationManagerCompat.from(context)
            .notify(Random.nextInt(), notification)
    } catch (_: SecurityException) {
    }
}