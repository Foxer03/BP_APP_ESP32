package com.example.bakalarka_default.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bakalarka_default.data.CardBackground
import com.example.bakalarka_default.data.ChartPoint
import java.io.OutputStreamWriter
import kotlin.math.roundToInt

@Composable
fun ChartCard(title: String, data: List<ChartPoint>, color: Color, unit: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(320.dp)
            .background(CardBackground, RoundedCornerShape(24.dp))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color(0xFF8B949E), fontSize = 12.sp)
                val last = data.lastOrNull()?.value
                Text(
                    text = if (last != null) "%.1f".format(last) else "--",
                    color = Color.White,
                    fontSize = 26.sp
                )
            }
            Box(
                modifier = Modifier.background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(999.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(unit, color = Color(0xFFC9D1D9), fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(12.dp))

        if (data.isNotEmpty()) {
            Box(modifier = Modifier.fillMaxSize()) {
                CoreGraphEngine(
                    datasets = listOf(data to color),
                    unit = unit,
                    yAxisLabel = title.substringBefore(" ").ifBlank { "Hodnota" },
                    xAxisLabel = "Čas"
                )
            }
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = color)
            }
        }
    }
}

@Composable
fun PillBottomBar(items: List<com.example.bakalarka_default.data.BottomNavItem>, selectedIndex: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier.background(Color.Black, RoundedCornerShape(30.dp)).padding(8.dp)
    ) {
        items.forEachIndexed { index, item ->
            val sel = index == selectedIndex
            Row(
                modifier = Modifier
                    .background(if (sel) Color(0xFF21262D) else Color.Transparent, RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .pointerInput(Unit) { detectTapGestures(onTap = { onSelect(index) }) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(item.icon, null, tint = if (sel) Color.White else Color.Gray)
                if (sel) {
                    Spacer(Modifier.width(8.dp))
                    Text(item.label, color = Color.White, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun CoreGraphEngine(
    datasets: List<Pair<List<ChartPoint>, Color>>,
    unit: String = "",
    yAxisLabel: String = "Hodnota",
    xAxisLabel: String = "Čas",
    showPointValues: Boolean = true,
    maxXLabels: Int = 5
) {
    val allPoints = datasets.flatMap { it.first }
    if (allPoints.isEmpty()) return
    val maxCount = datasets.maxOf { it.first.size }
    if (maxCount < 2) return

    val drawProgress: Float by animateFloatAsState(targetValue = 1f, label = "drawProgress")
    var touchIdx by remember { mutableStateOf<Int?>(null) }

    val leftPad = 84f
    val rightPad = 18f
    val topPad = 24f
    val bottomPad = 70f

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(datasets) {
                detectTapGestures(onTap = { offset ->
                    val w = size.width - leftPad - rightPad
                    if (w <= 1f) return@detectTapGestures
                    val x = (offset.x - leftPad).coerceIn(0f, w)
                    touchIdx = ((x / w) * (maxCount - 1)).toInt().coerceIn(0, maxCount - 1)
                })
            }
    ) {
        val w = size.width - leftPad - rightPad
        val h = size.height - topPad - bottomPad
        if (w <= 1f || h <= 1f) return@Canvas

        val rawMax = allPoints.maxOf { it.value }.coerceAtLeast(1f)
        val rawMin = allPoints.minOf { it.value }
        val range = (rawMax - rawMin).coerceAtLeast(1f)

        fun xFor(i: Int): Float = leftPad + (i / (maxCount - 1f)) * w
        fun yFor(v: Float): Float = topPad + (1f - ((v - rawMin) / range)) * h

        val axisPaint = android.graphics.Paint().apply {
            color = 0xFF8B949E.toInt(); textSize = 22f; isAntiAlias = true
        }
        val valuePaint = android.graphics.Paint().apply {
            color = 0xFFE6EDF3.toInt(); textSize = 20f; isAntiAlias = true; isFakeBoldText = true
        }

        repeat(5) { i ->
            val t = i / 4f
            val y = topPad + (1f - t) * h
            drawLine(Color.White.copy(alpha = 0.08f), Offset(leftPad, y), Offset(size.width - rightPad, y), 1.2f)
            val v = rawMin + range * t
            drawIntoCanvas { c -> c.nativeCanvas.drawText("%.1f".format(v), 10f, y + 8f, axisPaint) }
        }

        drawIntoCanvas { c ->
            c.nativeCanvas.drawText(if (unit.isBlank()) yAxisLabel else "$yAxisLabel ($unit)", 10f, 18f, axisPaint)
            c.nativeCanvas.drawText(xAxisLabel, leftPad, size.height - 14f, axisPaint)
        }

        val data0 = datasets.first().first
        val labelsCount = maxXLabels.coerceIn(3, 8)
        val idxs = (0 until labelsCount).map { k -> ((k / (labelsCount - 1f)) * (maxCount - 1)).toInt() }.distinct()
        idxs.forEach { idx ->
            val x = xFor(idx)
            drawLine(Color.White.copy(alpha = 0.10f), Offset(x, topPad + h), Offset(x, topPad + h + 10f), 1.2f)
            val label = data0.getOrNull(idx)?.dateTimeLabel.orEmpty().replace('_', ' ')
            drawIntoCanvas { c -> c.nativeCanvas.drawText(label.take(16), (x - 48f).coerceIn(leftPad, size.width - rightPad - 120f), size.height - 14f, axisPaint) }
        }

        datasets.forEachIndexed { sIdx, (data, color) ->
            if (data.size < 2) return@forEachIndexed
            val path = Path()
            val visibleCount = (data.size * drawProgress).toInt().coerceAtLeast(1).coerceAtMost(data.size)
            data.take(visibleCount).forEachIndexed { i, pt ->
                val x = xFor(i)
                val y = yFor(pt.value)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }

            val fillPath = Path().apply {
                addPath(path)
                lineTo(xFor(visibleCount - 1), topPad + h)
                lineTo(xFor(0), topPad + h)
                close()
            }
            drawPath(fillPath, Brush.verticalGradient(listOf(color.copy(alpha = 0.18f), Color.Transparent), startY = topPad, endY = topPad + h))
            drawPath(path, color, style = Stroke(width = 5.2f, cap = StrokeCap.Round))

            if (showPointValues && sIdx == 0) {
                val step = (data.size / 6).coerceIn(2, 6)
                for (i in 0 until visibleCount step step) {
                    val pt = data[i]
                    val x = xFor(i)
                    val y = yFor(pt.value)
                    drawIntoCanvas { c -> c.nativeCanvas.drawText("%.0f".format(pt.value), x - 10f, y - 14f, valuePaint) }
                }
            }
        }

        touchIdx?.let { idx ->
            val x = xFor(idx)
            drawLine(Color.White.copy(alpha = 0.22f), Offset(x, topPad), Offset(x, topPad + h), 1.3f)
            datasets.forEach { (data, color) ->
                val pt = data.getOrNull(idx) ?: return@forEach
                val y = yFor(pt.value)
                drawCircle(Color.White, radius = 9f, center = Offset(x, y))
                drawCircle(color, radius = 6f, center = Offset(x, y))
            }
        }
    }
}

private fun escapeXml(s: String): String = buildString(s.length) {
    for (ch in s) {
        when (ch) {
            '&' -> append("&amp;")
            '<' -> append("&lt;")
            '>' -> append("&gt;")
            '"' -> append("&quot;")
            '\'' -> append("&apos;")
            else -> append(ch)
        }
    }
}

fun buildLineGraphSvg(
    datasets: List<Pair<List<ChartPoint>, Color>>,
    seriesNames: List<String>,
    unit: String,
    width: Int = 1400,
    height: Int = 800,
    maxXLabels: Int = 7,
    annotateValues: Boolean = true
): String {
    val all = datasets.flatMap { it.first }
    if (all.isEmpty()) return ""

    val leftPad = 110f
    val rightPad = 40f
    val topPad = 55f
    val bottomPad = 120f

    val w = width.toFloat()
    val h = height.toFloat()
    val chartW = (w - leftPad - rightPad).coerceAtLeast(1f)
    val chartH = (h - topPad - bottomPad).coerceAtLeast(1f)
    val maxCount = datasets.maxOf { it.first.size }.coerceAtLeast(2)
    val maxV = all.maxOf { it.value }.coerceAtLeast(1f)
    val minV = all.minOf { it.value }
    val range = (maxV - minV).coerceAtLeast(1f)

    fun xFor(i: Int): Float = leftPad + (i / (maxCount - 1f)) * chartW
    fun yFor(v: Float): Float = topPad + (1f - ((v - minV) / range)) * chartH
    fun Color.toSvgHex(): String = "#%02X%02X%02X".format((red * 255).roundToInt(), (green * 255).roundToInt(), (blue * 255).roundToInt())
    val US = java.util.Locale.US
    fun f2(v: Float): String = String.format(US, "%.2f", v)
    fun f1(v: Float): String = String.format(US, "%.1f", v)
    fun f0(v: Float): String = String.format(US, "%.0f", v)

    val sb = StringBuilder()
    sb.appendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
    sb.appendLine("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"$width\" height=\"$height\" viewBox=\"0 0 $width $height\">")
    sb.appendLine("<rect x=\"0\" y=\"0\" width=\"$width\" height=\"$height\" fill=\"#0D1117\"/>")
    sb.appendLine("<rect x=\"${f2(leftPad)}\" y=\"${f2(topPad)}\" width=\"${f2(chartW)}\" height=\"${f2(chartH)}\" fill=\"#161B22\" rx=\"18\" ry=\"18\"/>")

    for (i in 0 until 5) {
        val t = i / 4f
        val y = topPad + (1f - t) * chartH
        val v = minV + range * t
        sb.appendLine("<line x1=\"${f2(leftPad)}\" y1=\"${f2(y)}\" x2=\"${f2(leftPad + chartW)}\" y2=\"${f2(y)}\" stroke=\"rgba(255,255,255,0.12)\" stroke-width=\"1\"/>")
        sb.appendLine("<text x=\"16\" y=\"${f2(y + 7f)}\" fill=\"#8B949E\" font-size=\"18\" font-family=\"sans-serif\">${f1(v)}</text>")
    }

    sb.appendLine("<text x=\"16\" y=\"30\" fill=\"#C9D1D9\" font-size=\"18\" font-weight=\"700\" font-family=\"sans-serif\">${escapeXml(if (unit.isNotBlank()) "Hladina ($unit)" else "Hladina")}</text>")

    datasets.forEach { (data, color) ->
        if (data.size < 2) return@forEach
        val hex = color.toSvgHex()
        val pts = buildString {
            data.forEachIndexed { i, pt ->
                append(f2(xFor(i))); append(","); append(f2(yFor(pt.value))); append(" ")
            }
        }.trim()
        sb.appendLine("<polyline points=\"$pts\" fill=\"none\" stroke=\"$hex\" stroke-width=\"4.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>")

        if (annotateValues) {
            val step = (data.size / 6).coerceIn(2, 8)
            for (i in 0 until data.size step step) {
                val pt = data[i]
                val x = xFor(i)
                val y = yFor(pt.value)
                sb.appendLine("<text x=\"${f2(x - 10f)}\" y=\"${f2(y - 10f)}\" fill=\"#E6EDF3\" font-size=\"14\" font-weight=\"700\" font-family=\"sans-serif\">${f0(pt.value)}</text>")
            }
        }
    }

    var legendY = topPad + 24f
    seriesNames.forEachIndexed { i, name ->
        if (name.isBlank()) return@forEachIndexed
        val c = datasets.getOrNull(i)?.second ?: return@forEachIndexed
        val hex = c.toSvgHex()
        sb.appendLine("<circle cx=\"${f2(leftPad + chartW - 150f)}\" cy=\"${f2(legendY)}\" r=\"6\" fill=\"$hex\"/>")
        sb.appendLine("<text x=\"${f2(leftPad + chartW - 136f)}\" y=\"${f2(legendY + 6f)}\" fill=\"#C9D1D9\" font-size=\"16\" font-family=\"sans-serif\">${escapeXml(name)}</text>")
        legendY += 24f
    }

    sb.appendLine("</svg>")
    return sb.toString()
}

@Composable
fun ExportSvgButton(
    svgFileName: String,
    svgProvider: () -> String
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("image/svg+xml")
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        val svg = svgProvider()
        if (svg.isBlank()) return@rememberLauncherForActivityResult
        try {
            context.contentResolver.openOutputStream(uri)?.use { os ->
                OutputStreamWriter(os, Charsets.UTF_8).use { it.write(svg) }
            }
        } catch (_: Exception) {
        }
    }

    Button(
        onClick = { launcher.launch(svgFileName) },
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF21262D))
    ) {
        Text("Export SVG", color = Color.White)
    }
}

@Composable
fun TimeRangePicker(
    data0: List<ChartPoint>,
    range: ClosedFloatingPointRange<Float>,
    onRangeChange: (ClosedFloatingPointRange<Float>) -> Unit
) {
    if (data0.size < 2) return

    val startIdx = range.start.toInt().coerceIn(0, data0.lastIndex)
    val endIdx = range.endInclusive.toInt().coerceIn(0, data0.lastIndex)

    fun niceLabel(idx: Int): String {
        val lbl = data0.getOrNull(idx)?.dateTimeLabel.orEmpty()
        return lbl.replace('_', ' ')
    }

    Column(
        modifier = Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(18.dp)).padding(12.dp)
    ) {
        Text("Časový úsek", color = Color(0xFFC9D1D9), fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Text("${niceLabel(minOf(startIdx, endIdx))}  →  ${niceLabel(maxOf(startIdx, endIdx))}", color = Color(0xFF8B949E), fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        RangeSlider(
            value = range,
            onValueChange = onRangeChange,
            valueRange = 0f..(data0.lastIndex.toFloat()),
            steps = (data0.size - 2).coerceAtLeast(0)
        )
    }
}
