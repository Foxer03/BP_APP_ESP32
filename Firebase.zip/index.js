/**
 * Import function triggers from their respective submodules:
 *
 * const {onCall} = require("firebase-functions/v2/https");
 * const {onDocumentWritten} = require("firebase-functions/v2/firestore");
 *
 * See a full list of supported triggers at https://firebase.google.com/docs/functions
 */

//const {setGlobalOptions} = require("firebase-functions");
//const {onRequest} = require("firebase-functions/https");
//const logger = require("firebase-functions/logger");

// For cost control, you can set the maximum number of containers that can be
// running at the same time. This helps mitigate the impact of unexpected
// traffic spikes by instead downgrading performance. This limit is a
// per-function limit. You can override the limit for each function using the
// `maxInstances` option in the function's options, e.g.
// `onRequest({ maxInstances: 5 }, (req, res) => { ... })`.
// NOTE: setGlobalOptions does not apply to functions using the v1 API. V1
// functions should each use functions.runWith({ maxInstances: 10 }) instead.
// In the v1 API, each function can only serve one request per container, so
// this will be the maximum concurrent request count.
//setGlobalOptions({ maxInstances: 2 });

// Create and deploy your first functions
// https://firebase.google.com/docs/functions/get-started
 //exports.helloWorld = onRequest((request, response) => {
  // logger.info("Hello logs!", {structuredData: true});
 //  response.send("Hello from Firebase!");
 //});

const { setGlobalOptions } = require("firebase-functions/v2");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const admin = require("firebase-admin");

admin.initializeApp();

setGlobalOptions({
  maxInstances: 2,
});

exports.bmp280AlertCheck = onSchedule("every 2 minutes", async (event) => {

  const db = admin.database();

  const devicesSnap = await db.ref("zariadenia").once("value");
  const devices = devicesSnap.val();

  if (!devices) return;

  const now = Date.now();
  const promises = [];

  for (const deviceId in devices) {

    const snap = await db
      .ref(`zariadenia/${deviceId}/bmp280`)
      .limitToLast(1)
      .once("value");

    const data = snap.val();
    if (!data) continue;

    const last = Object.values(data)[0];
    const temp = last.temperature;

    const lastAlert = devices[deviceId].lastAlert || 0;

    if (temp > 26 && now - lastAlert > 120000) {

      console.log(`🚨 ALERT: ${deviceId} = ${temp}`);

      promises.push(
        db.ref(`zariadenia/${deviceId}/lastAlert`).set(now)
      );

      promises.push(
        admin.messaging().send({
          topic: "alerts",
          notification: {
            title: "⚠️ Vysoká teplota",
            body: `${deviceId}: ${temp}°C`,
          }
        })
      );
    }
  }

  return Promise.all(promises);
});